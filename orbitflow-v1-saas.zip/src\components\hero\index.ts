export * from './WorkSmarterHeading';
